
#include"COLLECTION.h"
#include <string.h>
#include <fstream>
#include<conio.h>


template <class T>
int main(int argc, const char* argv[]) {
	Collection<T> *col;
	if (argc != 7 || argc != 5) {
		cout << "erorr : tham so dong lenh\n";
		_getch();
		return 0;
	}

	ofstream fout(argv[4]);
	int N = atoi(argv[2]);
	int sort = atoi(argv[1]);

	if (strcmp("int", argv[3])== 0) {
		col = new Collection<int>;
		int start = atoi(argv[5]);
		int end = atoi(argv[6]);
		col->RandDom(start, end);
	}
	else if (strcmp("float", argv[3]) == 0) {
		col = new Collection<float>;
		float start = atoi(argv[5]);
		float end = atoi(argv[6]);
		col.RandDom(start, end);
	}
	else if (strcmp("frac", argv[3]) == 0) {
		col = new Collection<FRAC>;
		col->RanDom();
	}
	
	switch (sort)
	{
	case 1: col->SelectionSort();
		break;
	case 2: col->InsertionSort();
		break;
	case 3: col->QuickSort(0, N - 1, compare);
		break;
	case 4: col->MergeSort(0, N - 1);
		break;
	case 5: col->HeapSort();
		break;
	case 6: col->QuickSort(0, N - 1, compare);
	default:
		break;
	}

	col->OutPut(fout);
	fout.close();
	return 0;
}