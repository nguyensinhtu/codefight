#pragma once
#include <iostream>
using namespace std;

class FRAC
{
public:
	FRAC();
	FRAC(int num, int deno);
	~FRAC();
	bool operator > (const FRAC& frac);
	bool operator < (const FRAC& frac);
	friend ostream& operator << (ostream& out,const  FRAC& frac);

	int getnum() { return numerator; }
	int getden() { return denominator; }
private:
	int numerator;
	int denominator;
};

FRAC::FRAC(int num, int deno) {
	numerator = num;
	denominator = deno;
}
FRAC::FRAC()
{
	numerator = 0;
	denominator = 0;
}

FRAC::~FRAC()
{
}

// toan tu so sanh hon
bool FRAC::operator > (const FRAC& frac) {
	double temp1 = numerator / double(denominator);
	double temp2 = frac.numerator / double(frac.denominator);
	if (temp1 > temp2)
		return true;
	return false;
}

bool FRAC::operator<(const FRAC& frac) {
	double temp1 = numerator / double(denominator);
	double temp2 = frac.numerator / double(frac.denominator);
	if (temp1 > temp2)
		return false;
	return true;
}

ostream& operator << (ostream& out, const FRAC& frac) {
	out << frac.numerator << "/" << frac.denominator;
	return out;
}


