#pragma once
# include "FRAC.h"
#include <time.h>
#include <iostream>
#include <vector>

using namespace std;

template <class T>
class Collection {
	int N;
	vector <T> arr;

public:
	Collection() {
		N = 0;
	}

	Collection(int n) {
		N = n;
	}

	~Collection() {
		arr.clear();
	}

	// Selection sort
	void SelectionSort();

	// InsertionSort
	void InsertionSort();

	// quick sort
	void QuickSort(int l, int r, const void* compare());

	// merge sort
	void MergeSort(int l, int r);
	void merge(int l, int r, int mid);

	// heap sort
	void HeapSort();
	void heapify(int i, int n);

	// random int
	void RanDom(int start, int end);

	// random float
	 void RanDom(float start, float end);
	
	// random fraction
	void RanDom();

	void OutPut(ostream &out);
};

template <class T>
void Collection<T>::SelectionSort()
{
	int i, j, min_idx;

	//duyet lan luot tung phan tu
	for (i = 0; i < N - 1; i++)
	{
		// tim kiem nhung phan tu chua duoc sap xep
		min_idx = i;
		for (j = i + 1; j < N; j++)
			if (arr[j] < arr[min_idx])
				min_idx = j;

		// hoan doi hai phan tu chua duoc sap
		swap(arr[min_idx], arr[i]);
	}
}


/* ham insertion sort*/
template <class T>
void Collection<T>::InsertionSort()
{
	int i, j;
	T key;
	for (i = 1; i < n; i++)
	{
		// lay khoa key ra de chen 
		key = arr[i];
		j = i - 1;

		/*di chuyen nhung phan tu truoc vi tri i
		len mot cho toi khi tim duoc vi tri co gia tri
		nho hon khoa key*/
		while (j >= 0 && arr[j] > key)
		{
			arr[j + 1] = arr[j];
			j = j - 1;
		}
		/* chen vao vi ri vua tim duoc*/
		arr[j + 1] = key;
	}
}

/* quick sort*/
template <class T>
void Collection<T>::QuickSort(int l, int r, const void *compare()) {

	if (l >= r) // neu left vuot qua right
		return;
	int mid = (r + l) / 2; // lay chi so giua
	T pivot = arr[mid]; // lay gia tri o giua
	int i = l;
	int j = r;
	do {
		while (compare(arr[i], pivot))
			++i;
		while (compare(pivot, arr[j]))
			--j;
		if (i <= j) {
			swap(arr[i], arr[j]);
			i++; --j;
		}
	} while (i <= j);

	QuickSort(l, mid, compare);
	QuickSort(mid + 1, r, compare);
}

// ham split and merge cac phan tu trong mang
template <class T>
void Collection<T>::merge(int l, int r, int mid) {
	if (l >= r)
		return;

	T *arrL = new T[mid - l + 1]; int nl = 0;
	T *arrR = new T[r - mid]; int nr = 0;

	// lay nhung phan ben trai mid
	for (int i = l; i <= mid; ++i) {
		arrL[nl] = arr[i]; ++nl;
	}
	// lay nhung phan tu ben phai mid
	for (int i = mid + 1; i <= r; ++i) {
		arrR[nr] = arr[i]; ++nr;
	}
	int k = l;
	int i = 0, j = 0;
	while (i < nl && j < nr) {
		if (arrL[i] < arrR[j]) {
			arr[k] = arrL[i];
			++i;
		}
		else {
			arr[k] = arrR[j];
			++j;
		}
		++k;
	}

	// dua not nhung phan tu o hai mang tro lai mang a;
	while (i < nl) {
		arr[k] = arrL[i];
		++i;
		++k;
	}


	while (j < nr) {
		arr[k] = arrR[j];
		++k;
		++j;
	}
	delete[] arrR;
	delete[] arrL;
}

// ham merge sort
template <class T>
void Collection<T>::MergeSort(int l, int r) {
	if (l >= r)
		return;
	int mid = (l + r) / 2;
	MergeSort(arr, l, mid);
	MergeSort(arr, mid + 1, r);
	merge(arr, l, r, mid);
}

// xap sep vun dong(heap sort)
// xet mang a voi goc o vi tri i
template <class T>
void Collection<T>::heapify(int i, int n) {
	int largest = i;
	int left = 2 * i + 1;
	int right = 2 * i + 2;

	if (left < n &&array[largest] < array[left])
		largest = left;
	if (right < n && array[largest] < array[right])
		largest = right;

	// neu goc khong phai la i
	if (largest != i) {
		swap(array[largest], array[i]);
		// xe cac goc tiep theo de dua phan tu lon nhat ve la goc
		heapify(largest, n);
	}
}

template <class T>
void Collection<T>::HeapSort()
{	// cap dong nhi phan
	for (int i = N / 2 - 1; i >= 0; i--)
		heapify(i, N);

	// duyet tung nut cua cay heap
	for (int i = n - 1; i >= 0; i--)
	{
		// lay nut dau cua cay(phan tu lon nhat) va dua phan tu cua nut cuoi cung ve
		swap(arr[0], arr[i]);
		// tao nut goc lon nhat
		heapify(0, i);
	}
}

// random int
template <class T>
void Collection::RanDom(int start, int end) {
	for (int i = 0; i < N; ++i) {
		srand(time(NULL));
		int num = rand % (end - start + 1) + start;
		arr.push_back(num);
	}
}

// random float
template <class T>
void Collection::RanDom(float start, float end) {
	for (int i = 0; i < N; ++i) {
		srand(time(NULL));
		float f = (float)rand() / RAND_MAX;
		float num = start + f * (start - end);
		arr.push_back(num);
	}
}

// random fraction
template <class T>
void Collection<T>::RanDom() {
	
	for (int i = 0; i < N; ++i) {
		srand(time(NULL));
		int num1 = rand;
		int num2 = rand;
		if (num2 != 0) {
			FRAC frac(num1, num2);
			arr.push_back(frac);
		}
	}
}

// ham xuat
template<class T>
void Collection<T>::OutPut(ostream &out) {
	for (int i = 0; i < N; ++i) {
		out << arr[i] << " " << endl;
	}
}